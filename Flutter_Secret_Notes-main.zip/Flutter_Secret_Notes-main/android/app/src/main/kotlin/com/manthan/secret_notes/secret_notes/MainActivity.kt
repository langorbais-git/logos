package com.manthan.secret_notes.secret_notes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
